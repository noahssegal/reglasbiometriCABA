#!/bin/bash
# Doble clic en este archivo para chequear y reconstruir el sitio.
cd "$(dirname "$0")"
echo "════════════════════════════════════════"
echo "  Marco legal — actualizar sitio"
echo "════════════════════════════════════════"
echo
echo "1/3  Chequeando el corpus..."
if ! python3 chequeos.py; then
  echo
  echo "⚠  Hay algo que revisar. No se reconstruyó nada."
  echo "   Corregí lo de arriba en data/fichas.json y volvé a intentar."
  echo
  read -p "Enter para cerrar."
  exit 1
fi
echo
echo "2/3  Construyendo el sitio..."
python3 construir.py
echo
echo "3/3  Regenerando la tabla de verificación..."
python3 verificar.py
echo
echo "════════════════════════════════════════"
echo "  Listo."
echo "  Sitio:  dist/index.html"
echo "  Tabla:  verificacion/tabla.html"
echo "════════════════════════════════════════"
echo
read -p "Enter para cerrar."
