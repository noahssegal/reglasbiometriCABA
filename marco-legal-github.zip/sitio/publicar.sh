#!/bin/bash
# Chequea, construye y regenera la tabla de verificacion.
# Uso:  ./publicar.sh        (desde la carpeta sitio/)
set -e
cd "$(dirname "$0")"
echo "→ chequeos"
python3 chequeos.py
echo "→ construir"
python3 construir.py
echo "→ tabla de verificacion"
python3 verificar.py
echo
echo "Listo. Abrir docs/index.html"
