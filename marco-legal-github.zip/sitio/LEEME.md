# Cómo funciona esta carpeta

## Lo primero: no hace falta la Terminal

Se puede pedir la reconstrucción del sitio en la conversación y listo. Lo que
sigue es para hacerlo sin ayuda, si alguna vez conviene.

## Opción fácil: doble clic

Doble clic en **`Actualizar sitio.command`**.

Se abre una ventana negra, corre los tres pasos y avisa cuando termina. Se
cierra apretando Enter.

La primera vez macOS puede decir que no se puede abrir porque es de un
desarrollador no identificado. En ese caso: clic derecho sobre el archivo →
Abrir → Abrir. Solo hace falta una vez.

## Qué hace cuando se corre

1. **Chequea** el corpus. Si encuentra algo mal, muestra la lista y **no
   reconstruye nada**. Es deliberado.
2. **Construye** el sitio en `docs/`.
3. **Regenera** la tabla de verificación.

## Qué puede salir mal

Poco. Los tres programas solo leen los archivos de `data/` y escriben en
`docs/` y en `verificacion/`. **Nunca modifican el contenido.**

Una sola cosa a saber: al construir, la carpeta `docs/` se borra y se vuelve a
generar entera. Todo lo que está ahí adentro es automático y se puede rehacer,
así que no hay nada que perder — pero conviene no guardar nada propio dentro de
`docs/`, porque desaparece en la siguiente corrida.

Si algo falla a mitad de camino, volver a correrlo arregla la situación. No hay
un estado a medias que quede roto.

## Dónde vive el texto

Todo el contenido está en cuatro archivos dentro de `data/`:

- `fichas.json` — las veinte fichas
- `derechos.json` — la página "Qué se puede hacer"
- `encuadre.json` — la página "Sobre este sitio"
- `cronologia.json` — la portada

Se editan con cualquier editor de texto y se vuelve a correr. Son los archivos
que importan: si hubiera que respaldar algo, es esta carpeta.

## Qué mirar después

- `docs/index.html` — el sitio, doble clic para abrirlo en el navegador
- `verificacion/tabla.html` — la tabla para cotejar afirmación contra fuente
