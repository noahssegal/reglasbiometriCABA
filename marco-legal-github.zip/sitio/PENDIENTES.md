# Pendientes del sitio

## Cambios pedidos por Noah (04/08/2026, sin aplicar todavía)

1. **La cronología pasa a ser la página principal.** Hoy `index.html` es el índice
   y `cronologia.html` una página aparte. Invertir: la cronología es la portada;
   el índice pasa a `indice.html` y queda en la navegación.

2. **Falta una página de encuadre.** Qué es este corpus, qué incluye y qué no,
   cómo leerlo. Existe un borrador previo en los archivos del Proyecto:
   `pagina_como_leer_este_sitio_2026-07-12.md` — tres bloques (jerarquía
   normativa, federalismo, DNU), con citas constitucionales cotejadas contra el
   PDF oficial de Casa Rosada el 12/07/2026. Revisar el registro contra las
   reglas actuales (sin tono activista, sin segunda persona) antes de usarlo.

3. **Centrar el texto de la cabecera.** Hoy la marca va a la izquierda y la
   navegación a la derecha. Centrar el bloque superior.

4. **Los estados deben alternar ES/EN.** Hoy "vigente", "disputado", "firme",
   "en comisiones" quedan fijos en castellano en las dos versiones. Desdoblar
   `estado` en `estado_es` / `estado_en` en `data/fichas.json` (13 estados
   distintos en el corpus).

5. **Los nombres de las normas deben alternar ES/EN.** Decisión abierta: se
   propone mantener fijo el identificador del instrumento (Ley 5688, RG AFIP
   5266/2022, Decreto 1766/2011) y traducir solo la glosa entre paréntesis
   ("protección de datos personales" → "personal data protection"). Traducir el
   identificador ("Law 5688") rompe la búsqueda del documento oficial, que solo
   existe en castellano. Confirmar con Noah antes de aplicar a las 19 fichas.

6. **Pie del sitio, texto corregido (aplicar):** "Every statement cites an
   official document and date accessed. Entry notes where fact could not be
   verified against primary source." Considerar una segunda oración para el caso
   distinto de los anexos reservados: documento verificado como existente pero
   retirado de publicación (Res. MS 1234/2024; Disp. RENAPER 1255/2023).

7. **La marca del sitio debe alternar ES/EN.** "Marco legal" → en inglés.
   Opciones a decidir: "Legal framework" (traducción directa), "The legal
   framework" o un nombre propio que no se traduzca en ninguna versión. Si el
   sitio lleva nombre propio, conviene fijarlo antes de que aparezca en el
   encabezado, el título de cada página y las citas externas.

8. Noah va a hacer una revisión más detallada del sitio; esperar esos comentarios
   antes de tocar tipografía y espaciado.

## Verificaciones abiertas del corpus (heredadas)

- Enlaces oficiales faltantes: consolidación vigente de la Ley 5688; DNU 941/2025;
  sentencia de Cámara (28/04/2023); resolución PIA (legajo 228/22); Res. 351/2024.
  Al cargarlos en `data/fichas.json` se convierten en enlaces solos.
- Res. MS 1234/2024: confirmar directamente el contenido del único adjunto
  publicado en la edición web del BORA.
- Clearview: disposición de adjudicación de la renovación 2026, no publicada al
  20/07/2026.
- Descripción pública de cómo opera Clearview: requiere fuente oficial externa;
  no entra al cuerpo sin ella.
- Prórrogas de la exención biométrica de AFIP (RG 4776/2020, 4867/2020, 5038/2021,
  5180/2022): identificadas, textos individuales sin leer uno por uno.
- Fidelity pass sobre las 19 fichas, cuando el texto quede congelado.
