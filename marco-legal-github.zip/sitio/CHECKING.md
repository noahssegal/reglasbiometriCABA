# Checking — what's done, what isn't, what to do

Status as of 07/08/2026. The procedure this measures against is `FIDELITY_PASS.md`.

---

## Has a fidelity pass been completed?

No. Roughly a third of it has, and the preconditions for starting it are not met.

| Step | Status |
|---|---|
| **0.1** Text frozen | **No.** 18 entries were rewritten today. |
| **0.2** Registry reconciliation | **Stale.** Done in July; not redone after adding Ley 6339, Decreto 346/2009 and Ley 25.520 to the corpus. |
| **0.3** Source acquisitions closed | **No.** 11 documents still not obtained. 8 entries cite sources with no resolvable official URL. |
| **1** Mechanical checks | **Partial.** `chequeos.py` passes: footnote parity, sources cited both ways, no future read-dates, no broken chronology links, title instrument present in its own source. Not done: verbatim matching of the site's own quotations against stored source text, link resolution, cross-reference checks. |
| **2** Blind re-derivation | **Not started.** This is the core of the pass. The independent reading covered 9 of 20 entries and answered my questions, not the entries. |
| **3** Non-per-entry checks | **Not done.** Absence claims not re-run. ES/EN not compared for meaning. Statuses not confirmed to today. |
| **4** Difference log and sign-off | **Not done.** |

**Coverage:** 47 statements across 53 source documents. 9 entries of 20 have had
an independent reading; 11 have not, accounting for 62 footnote references.

---

## What I may have made worse today

I bulk-replaced the English text of 18 entries from your v3 document. `chequeos.py`
verifies that the same footnote *numbers* appear in Spanish and English — not that
the two say the same thing. Your edits changed English wording in ways the Spanish
has not followed except where I noticed and synced it by hand.

So the Spanish/English divergence risk is **higher now than it was this morning**,
and it is invisible to every automated check I have.

Two entries were deliberately excluded from that replacement — Ley 5688 and
DNU 941/2025 — because I had rewritten them from new findings. That means **your
stylistic edits to those two entries were not applied either.** They need your eye.

---

## What to check, in order

### 1. Spanish against English, all 20 entries

Your comparative advantage, and the risk I just created. Read the two side by side
and flag anything where they do not assert the same thing. Watch the terms that
carry legal weight: *cancelación* vs deletion, *cesión* vs transfer, *reservado* vs
secret, *días corridos* vs *días hábiles*.

Start with the 18 I replaced. Ley 5688 and DNU 941 are the two I wrote fresh today,
so read those for style as well as meaning.

### 2. The rights page

Highest consequence on the site. A mis-transcribed deadline can cost someone a
right. Lotes 9 and 10 confirmed the underlying articles of Ley 25.326 and
Ley 27.275, but nobody has checked that the page renders those articles into
procedures correctly.

Read each block against the statute text in `lotes_verificacion/`, not against
this version.

### 3. The 11 entries with no independent reading

In this order, by exposure:

| Entry | Notes | Why first |
|---|---|---|
| `nac-torres-abad` | 8 | The Ley 25.326 entry leans on this ruling and I don't hold its full text. |
| `nac-proyectos-facial` | 10 | Bills change status; ten claims resting on it. |
| `caba-clearview` | 6 | Contractual claims about a private vendor. |
| `nac-renaper` | 7 | You flagged the framing yourself (SN6, SN7). |
| `nac-afip` | 6 | Site of the known drift precedent (RG 4699/2020). |
| `nac-res-ms-1234` | 5 | Reserved annexes; claims about what is withheld. |
| `nac-gemelo-digital` | 5 | An entry built on a documented absence. |
| `nac-convenios-108` | 5 | You asked what the treaty commits Argentina to (SN8). |
| `nac-dto-98-2023` | 4 | You flagged a sentence as unhelpful (SN11). |
| `nac-res-ms-866` | 4 | — |
| `nac-aicr` | 2 | — |

### 4. Statuses

Every *vigente*, *firme*, *en comisiones* is asserted as of the last session that
touched it, not as of today. Confirm each.

### 5. The eight entries with no resolvable official URL

`caba-caso-srfp`, `nac-uiaas-710-2024`, `nac-res-ms-1234`, `caba-clearview`,
`nac-dnu-941`, `nac-aicr`, `nac-torres-abad`, `nac-proyectos-facial`.

A public corpus whose citations can't be followed is weaker than one with fewer
entries. Either find the official link or say in the entry that it isn't published.

---

## One change I'd make before posting

The About page says every statement cites an official document and the date it was
read. That is true. It does not say that verification is incomplete, and a reader
would reasonably assume otherwise from how carefully everything else is qualified.

Draft, to sit under "How sources work" — say the word and I'll add it:

> **Verificación**
> El corpus no completó todavía su revisión final. Nueve de las veinte fichas
> pasaron por una lectura independiente contra el documento original; las once
> restantes se apoyan por ahora en una sola lectura. Ocho fichas citan documentos
> cuyo enlace oficial no está resuelto. Esta versión se publica en ese estado, y
> no como un texto cerrado.

> **Verification**
> The corpus has not yet completed its final review. Nine of the twenty entries
> have been through an independent reading against the original document; the
> remaining eleven rest for now on a single reading. Eight entries cite documents
> whose official link is unresolved. This version is published in that state, not
> as a closed text.
